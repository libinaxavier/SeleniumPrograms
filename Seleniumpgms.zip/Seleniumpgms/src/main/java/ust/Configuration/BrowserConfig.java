package ust.Configuration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class BrowserConfig {
 
	public static WebDriver getBrowser() {
		
	ChromeOptions c=new ChromeOptions();
	c.addArguments("--remote-allow-origins=*");
	c.addArguments("--disable-notifications");
    WebDriver driver=new ChromeDriver(c);
    return driver;
		
	}
}
