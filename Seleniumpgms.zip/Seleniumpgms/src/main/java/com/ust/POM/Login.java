package com.ust.POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Login {
	WebDriver driver;
	public Login(WebDriver driver) {
		this.driver=driver;
	}
	//Giving Locators
	
	By username=By.name("user");
    By password=By.name("pass");
    By submit=By.name("btnSubmit");
    
  //Giving elements as methods
    
    public void username(String user) {
    	WebElement uname=driver.findElement(username);
    	if(uname.isEnabled()==true)
    	uname.sendKeys(user);
    }
    public void passWord(String pass) {
    	WebElement pword=driver.findElement(username);
    	if(pword.isEnabled()==true)
    	pword.sendKeys(pass);
    }
    
    public void submit() {
    	WebElement subit=driver.findElement(submit);
    	subit.click();
    }
}
