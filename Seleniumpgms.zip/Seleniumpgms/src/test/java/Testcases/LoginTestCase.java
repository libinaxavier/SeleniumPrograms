package Testcases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ust.POM.Login;

import ust.Configuration.BrowserConfig;

public class LoginTestCase {
	WebDriver driver;
	
	@BeforeTest
	public void setup() {
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://www.mycontactform.com");
		 driver.manage().window().maximize();
	}
	
	@Test(priority=0)
	public void UsernameTest() {
		Login login=new Login(driver);
		login.username("Libina");
	}

	@Test(priority=1)
	public void PasswordTest() {
		Login login=new Login(driver);
		login.username("Libina@123");
	}
	@Test(priority=2)
	public void SubmitTest() {
		Login login=new Login(driver);
		login.submit();
	}
	
//	@AfterTest
//	public void teardown() {
//		driver.close();
//	}
}
