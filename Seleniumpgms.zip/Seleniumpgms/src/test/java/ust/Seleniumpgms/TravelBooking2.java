package ust.Seleniumpgms;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import ust.Configuration.BrowserConfig;

public class TravelBooking2 {
	private static final WebElement November = null;
	WebDriver driver;
	
	@Test
	public void travel() throws InterruptedException {
		String s="November";
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://www.ixigo.com/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("(//input[@class='c-input u-v-align-middle'])[3]")).click();
		for(int i=0;i<12;i++)
		{
		WebElement d= driver.findElement(By.xpath("(//div[@class='rd-month-label'])[1]"));
		String a=d.getText();
		String arr[]=a.split(" ");
		if(((arr[0].equals(s))))
		{
		break;
		}
		else
		{
		WebElement m=driver.findElement(By.xpath("//button[@class='ixi-icon-arrow rd-next']"));
		Thread.sleep(3000);
		m.click();
		}
		}




	    
	}
}
