package ust.Seleniumpgms;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import ust.Configuration.BrowserConfig;

public class AmazonProduct {
 WebDriver driver;
 
 @Test
 public void amazon() {
	 driver=BrowserConfig.getBrowser();
		driver.get("https://www.amazon.com/");
		driver.manage().window().maximize();
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("JBL bluetooth speakers");
		driver.findElement(By.id("nav-search-submit-button")).click();
		
		driver.findElement(By.xpath("//*[@id=\"p_89/JBL\"]/span/a/div/label/i")).click();
		driver.findElement(By.className("a-dropdown-label")).click();
		driver.findElement(By.id("s-result-sort-select_1")).click();
		for(int i=0;i<5;i++) {
		List<WebElement>links=driver.findElements(By.xpath("//h2[contains(@class,'a-size-mini a')]//a//span"));
		links.get(i);
		}
		for(int i=0;i<5;i++) {
			List<WebElement>links1=driver.findElements(By.xpath("//h2[contains(@class,'a-size-mini a')]//a//span"));
			System.out.println(links1.get(i).getText());
 }
}
}