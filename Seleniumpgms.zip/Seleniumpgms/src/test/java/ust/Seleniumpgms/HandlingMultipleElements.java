package ust.Seleniumpgms;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import ust.Configuration.BrowserConfig;

public class HandlingMultipleElements {

	WebDriver driver;
	@Test
public void multele() throws IOException {
	driver=BrowserConfig.getBrowser();
	driver.navigate().to("https://www.mycontactform.com");
    driver.manage().window().maximize();
    WebElement link=driver.findElement(By.linkText("Sample Forms"));
    link.click();
    
    //Print number of links 
    List <WebElement> links=driver.findElements(By.tagName("a"));
    System.out.println(links.size());
    
    //Print all links
    for(int i=0;i<links.size();i++) {
    	System.out.println(links.get(i).getAttribute("href"));
    }
 
    
    for(int i=0;i<31;i++) {
    
    		List <WebElement> link1=driver.findElements(By.xpath("//div[@id='left_col_top']//ul//li//a"));
    		link1.get(i).click();
    		
    	
    }
    
    //Convert webdriver object to takescreenshot
    TakesScreenshot src1=(TakesScreenshot) driver;
    
    //call getscreenshotmethod to create image file
    File src2=src1.getScreenshotAs(OutputType.FILE);
    
    //move to image file to destination
    // FileUtils.copyFile(src2,new File("C:\\Users\\249459\\Desktop\\javacodes\\Seleniumpgms\\src\\main\\java\\Screenshots\\aa.jpg"));
	
	
	//Taking multiple screenshots
	for(int i=0;i<31;i++) {
		FileUtils.copyFile(src2,new File("C:\\Users\\249459\\Desktop\\javacodes\\Seleniumpgms\\src\\main\\java\\Screenshots\\aa["+i+"].jpg"));
	}
}
}
