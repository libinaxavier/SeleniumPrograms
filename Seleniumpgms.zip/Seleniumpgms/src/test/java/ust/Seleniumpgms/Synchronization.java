package ust.Seleniumpgms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import ust.Configuration.BrowserConfig;

public class Synchronization {
 
	WebDriver driver;
	
	@Test
	public void synch() {
		driver=BrowserConfig.getBrowser();
		   driver.navigate().to("http://www.uitestingplayground.com/");
		   driver.manage().window().maximize();
		   WebElement link=driver.findElement(By.linkText("AJAX Data"));
		   link.click();
		   driver.findElement(By.id("ajaxButton")).click();
		   WebElement txt1=driver.findElement(By.id("content"));
		   System.out.println(txt1.getText());
	}
	
}
