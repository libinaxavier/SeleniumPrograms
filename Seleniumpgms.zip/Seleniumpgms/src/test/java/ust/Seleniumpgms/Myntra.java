package ust.Seleniumpgms;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import ust.Configuration.BrowserConfig;

public class Myntra {
	WebDriver driver;
	@Test
	public void myn() {
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://www.myntra.com/");
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)","");
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
	}

}
