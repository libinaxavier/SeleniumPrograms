package ust.Seleniumpgms;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import ust.Configuration.BrowserConfig;

public class travel {
   WebDriver driver;
   
	@Test
	public void booking() throws InterruptedException {
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://www.ixigo.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		//from 
		
    	WebElement fromElement=driver.findElement(By.xpath("(//input[@class='c-input u-v-align-middle'])[1]"));
//		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
//		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("(//input[@class='c-input u-v-align-middle'])[1]")));
		fromElement.click();
		fromElement.sendKeys("MAA-Chennai");
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.ENTER);
		
		//to
		WebElement toElement=driver.findElement(By.xpath("(//input[@class='c-input u-v-align-middle'])[2]"));
		toElement.click();
		toElement.sendKeys("BOM");
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.ENTER);
		driver.findElement(By.xpath("(//input[@class='c-input u-v-align-middle'])[3]")).click();
		String s="November";
		for(int i=0;i<12;i++)
		{
		WebElement d= driver.findElement(By.xpath("(//div[@class='rd-month-label'])[1]"));
		String a=d.getText();
		String arr[]=a.split(" ");
		if(((arr[0].equals(s))))
		{
		break;
		}
		else
		{
		WebElement m=driver.findElement(By.xpath("//button[@class='ixi-icon-arrow rd-next']"));
		Thread.sleep(3000);
		m.click();
		}
		}

	}
	
	//*[@id="content"]/div/div[1]/div[5]/div/div/div[1]/div/div[1]/input
}
