package ust.Seleniumpgms;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import ust.Configuration.BrowserConfig;

public class MultipleWindows {

	WebDriver driver;
	@Test
	public void sample() {
		driver=BrowserConfig.getBrowser();
		//driver.navigate().to("https://nxtgenaiacademy.com/multiplewindows/");
		driver.navigate().to("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
		//driver.findElement(By.name("123newmessagewindow321")).click();
		//driver.findElement(By.linkText("open New Seperate Window")).click();
		WebElement link=driver.findElement(By.linkText("click"));
		link.click();
		
		Set <String> windows=driver.getWindowHandles();
		System.out.println(windows.size());
		List<String> w=new ArrayList<>(windows);
		driver.switchTo().window(w.get(1));
		
        WebElement text=driver.findElement(By.xpath("/html/body/div/main/section[1]/div/div/div/h1"));
		System.out.println(text.getText());
	
		driver.switchTo().window(w.get(0));
		WebElement txt1=driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/h1"));
		System.out.println(txt1.getText());
	}
}
