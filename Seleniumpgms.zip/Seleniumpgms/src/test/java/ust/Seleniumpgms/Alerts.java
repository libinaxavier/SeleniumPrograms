package ust.Seleniumpgms;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import ust.Configuration.BrowserConfig;

public class Alerts {
 WebDriver driver;
	@Test
	public void alert() {
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://testpages.herokuapp.com/styled/index.html");
		driver.manage().window().maximize();
		driver.findElement(By.id("alerttest")).click();
		driver.findElement(By.id("alertexamples")).click();
		Alert alert=driver.switchTo().alert();
		alert.dismiss();
		
	}
}
