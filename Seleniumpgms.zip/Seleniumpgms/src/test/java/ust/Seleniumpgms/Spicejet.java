package ust.Seleniumpgms;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import ust.Configuration.BrowserConfig;

public class Spicejet {
 WebDriver driver;
	@Test
	public void spicejet() {
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://www.spicejet.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
        //from 
		
//    	WebElement fromElement=driver.findElement(By.xpath("(//input[@class='c-input u-v-align-middle'])[1]"));
//		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
//		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("(//input[@class='c-input u-v-align-middle'])[1]")));
//		fromElement.click();
//		fromElement.sendKeys("MAA-Chennai");
//		driver.findElement(By.cssSelector("body")).sendKeys(Keys.ENTER);
//		
		
	}
}
