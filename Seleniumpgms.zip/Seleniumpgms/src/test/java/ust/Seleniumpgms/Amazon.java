package ust.Seleniumpgms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;
import ust.Configuration.BrowserConfig;

public class Amazon {
	WebDriver driver;
	
	@Test
	public void AmazonOpen() {
		driver=BrowserConfig.getBrowser();
		driver.get("https://www.mycontactform.com/");
		driver.manage().window().maximize();
//		WebElement nav=driver.findElement(By.id("nav-link-accountList-nav-line-1"));
//		nav.click();
		System.out.println(driver.getTitle());
		
		//WebElement nav=driver.findElement(By.id("nav-link-accountList"));
		/*Actions a=new Actions(driver);
		a.moveToElement(nav).perform();
		driver.findElement(By.linkText("Recommendations")).click();
		*/
		}




}
