package ust.Seleniumpgms;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;
import ust.Configuration.BrowserConfig;

public class GoogleSearch {
     WebDriver driver;
	@Test
	public void googlesearch() throws InterruptedException {
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://www.google.com");
		driver.manage().window().maximize();
		//Thread.sleep(3000);
		driver.findElement(By.id("APjFqb")).sendKeys("selenium");
		//Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[1]/div[3]/form/div[1]/div[1]/div[4]/center/input[1]")).click();
		
//		boolean islinkpresent=driver.findElement(By.xpath("//*[@id=\"rso\"]/div[1]/div/div/div/div/div/div/div/div[1]/a/div/div/div/cite")).isDisplayed();
//		assertTrue(islinkpresent);
	//String expected="https://www.selenium.dev";
	String actual=driver.findElement(By.xpath("//*[@id=\"rso\"]/div[1]/div/div/div/div/div/div/div/div[1]/a/div/div/div/cite")).getText();
//		assertEquals(actual,expected);
		//Thread.sleep(3000);
	//WebElement txt1=driver.findElement(By.xpath("//*[@id=\\\"rso\\\"]/div[1]/div/div/div/div/div/div/div/div[1]/a/div/div/div/cite"));
	
	//System.out.println(txt1.getText());
	assertEquals(actual,"https://www.selenium.dev");
		
	} 
//	
//	//close the browser
//	@AfterMethod
//	public void dos() {
//		driver.close();
//	}
	
}
