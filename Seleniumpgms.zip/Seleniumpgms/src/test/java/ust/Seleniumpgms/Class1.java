package ust.Seleniumpgms;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;


public class Class1 {
	
   @Test
   public void getBrowser() {
	   
//	   //to open browser
//	   ChromeOptions c=new ChromeOptions();
//	   c.addArguments("--remote-allow-origins**");
	   WebDriver driver=new EdgeDriver();
	   
	   //if edge-> WebDriver driver=new EdgeDriver();
	   //to navaigate to  website (synchronized->wait until loading)
	   //driver.get("https://www.google.com");
	   
	   //to navigate to website
	   driver.navigate().to("https://demo.nopcommerce.com/");
	   
	   //navigational method
//	   driver.navigate().back();
//	   driver.navigate().forward();
//	   driver.navigate().refresh();
//	   
//	   //to maximize the window
//	   driver.manage().window().maximize();
	   
	   String title=driver.getTitle();
	   String url=driver.getCurrentUrl();
	   System.out.println(title);
	   System.out.println(url);
	   
		}

	}


