package ust.Seleniumpgms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import ust.Configuration.BrowserConfig;

public class Class2 {
	WebDriver driver;
	
	@Test
	public void query() {
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://jqueryui.com/");
		driver.manage().window().maximize();
		WebElement link=driver.findElement(By.linkText("Droppable"));
		link.click();
		
		//Drag and Drop
		WebElement f=driver.findElement(By.className("demo-frame"));
		driver.switchTo().frame(f);
		
		
		WebElement src=driver.findElement(By.id("draggable"));

		WebElement dest=driver.findElement(By.id("droppable"));
		
		Actions a=new Actions(driver);
		a.clickAndHold(src).moveToElement(dest).release(dest).build().perform();
		
	}

}
