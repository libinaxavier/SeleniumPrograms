package ust.Seleniumpgms;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import ust.Configuration.BrowserConfig;


public class Locators {
	WebDriver driver;
	@Test
    
	public void locators()
	{
		/*
		 * id
		 * name
		 * linktext -> <a></a>
		 * classname
		 * xpath
		 * cssselector
		 */
		
		  driver=BrowserConfig.getBrowser();
		   driver.navigate().to("https://www.mycontactform.com");
		   driver.manage().window().maximize();
		   //driver.findElement(By.linkText("Sample Forms")).click();  or below one
		   WebElement link=driver.findElement(By.linkText("Sample Forms"));
		   link.click();
		   driver.findElement(By.id("subject")).sendKeys("Libina");
		   driver.findElement(By.name("email")).sendKeys("libinax1998@gmail.com");
		   driver.findElement(By.id("q1")).sendKeys("hello");
		   driver.findElement(By.name("q2")).sendKeys("To make sure that your progress is recorded, please close the window when you are done with your training.");	
		 
		   //CheckBox(send to)
		   driver.findElement(By.xpath("//input[@name='email_to[]'][@value='1']")).click();
		   
		   //DropDown
		   WebElement dd=driver.findElement(By.id("q3"));
		   Select s=new Select(dd);
		   //s.selectByVisibleText("Second Option");
		   s.selectByIndex(2);
		   
		   //Radio
		  // WebElement rr=driver.findElement(By.id("q4"));
		 //  rr.click();
		   driver.findElement(By.xpath("//input[@name='q4'][@value='Third Option']")).click();
		
		   //checkbox single
		    driver.findElement(By.xpath("//input[@name='q5'][@value='Yes']")).click();
		    
		    //Checkbox multi
		    driver.findElement(By.xpath("//input[@name='checkbox6[]'][@value='Second Check Box']")).click();
		    driver.findElement(By.xpath("//input[@name='checkbox6[]'][@value='Fourth Check Box']")).click();
		    
		    //date selector
		    driver.findElement(By.id("q7")).sendKeys("2-12-1998");
		   
		    //pre-defined fields-us states
		    WebElement d1=driver.findElement(By.id("q8"));
			Select s1=new Select(d1);
			s1.selectByIndex(5);
		   
			//pre-defined fields -countries
			WebElement d2=driver.findElement(By.id("q9"));
			Select s2=new Select(d2);
			s2.selectByIndex(8);
			
			//pre-defined fields-canadian provinces
			
			WebElement d3=driver.findElement(By.id("q10"));
			Select s3=new Select(d3);
			s3.selectByVisibleText("Ontario");
			
			//predefined fields -name
			
			WebElement d4=driver.findElement(By.name("q11_title"));
			Select s4=new Select(d4);
			s4.selectByVisibleText("Dr.");
			
			driver.findElement(By.name("q11_first")).sendKeys("Libina");
			driver.findElement(By.name("q11_last")).sendKeys("Xavier");
		   
		   //date 
			WebElement d5=driver.findElement(By.name("q12_month"));
			Select s5=new Select(d5);
			s5.selectByVisibleText("11");
			
			WebElement d6=driver.findElement(By.name("q12_day"));
			Select s6=new Select(d6);
			s6.selectByVisibleText("24");
			
			WebElement d7=driver.findElement(By.name("q12_year"));
			Select s7=new Select(d7);
			s7.selectByVisibleText("2000");
			
			//file upload
			driver.findElement(By.id("attach4589")).sendKeys("C:\\Users\\249459\\Desktop\\automationsample.txt");
			
			//enter verification code
			
			//driver.findElement(By.id("visver_code")).sendKeys("D7E7");
			
			//submit
			driver.findElement(By.name("submit")).click();
			
			//reset
			//driver.findElement(By.id("reset")).click();
			
			//print
			//driver.findElement(By.id("print")).click();
	}

}
