package ust.Seleniumpgms;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import ust.Configuration.BrowserConfig;

public class Ajio {
 WebDriver driver;
 @Test
 public void shoes() {
	 driver=BrowserConfig.getBrowser();
	 driver.navigate().to("https://www.ajio.com/");
	 driver.manage().window().maximize();
	 
	WebElement link=driver.findElement(By.xpath("//*[@id=\"appContainer\"]/div[1]/div/header/div[3]/div[1]/ul/li[1]/a"));
	 Actions action=new Actions(driver);
     action.moveToElement(link).perform();
     driver.findElement(By.linkText("Casual Shoes")).click();
     //driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
     //driver.findElement(By.linkText("US Polo Assn")).click();
     driver.findElement(By.xpath("//*[@id=\"modalId\"]/div/div/form/div/div[2]/ul[2]/li[2]/div/label/span/span[1]")).click();
     //driver.findElement(By.linkText("Relevance")).click();
	 }
}
