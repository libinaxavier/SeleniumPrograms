package ust.Seleniumpgms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import ust.Configuration.BrowserConfig;

public class Ebay {
 WebDriver driver;
  @Test
  public void search() {
//	  driver=BrowserConfig.getBrowser();
//	  driver.navigate().to("https://www.ebay.com");
//	  driver.manage().window().maximize();
//	  driver.findElement(By.id("gh-ac")).sendKeys("selenium");
//	  driver.findElement(By.id("gh-btn")).click();
//	  driver.findElement(By.xpath("//*[@id=\"mainContent\"]/div[1]/div/div[1]/div[2]/div[1]/div/ul/li[3]/a/span")).click();
	 // WebElement dd=driver.findElement(By.className("fake-menu-button__button btn btn--small btn--secondary"));
	  // Select s=new Select(dd);
	 
	 //  s.selectByIndex(2);
	  
}
}