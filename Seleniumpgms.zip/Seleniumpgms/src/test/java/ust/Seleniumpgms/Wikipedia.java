package ust.Seleniumpgms;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import ust.Configuration.BrowserConfig;

public class Wikipedia {

	WebDriver driver;
	@Test
	public void wiki() {
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://www.wikipedia.org/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//a[@id=\"js-link-box-en\"]")).click();
		driver.findElement(By.xpath("//input[@class='cdx-text-input__input']")).sendKeys("List of countries and dependencies by population");
		driver.findElement(By.xpath("//button[@class='cdx-button cdx-search-input__end-button']")).click();
		int rowcount=driver.findElements(By.xpath("//table[@class='wikitable sortable jquery-tablesorter']/tbody/tr")).size();
	    System.out.println("rows:"+rowcount);
		
	    List<WebElement>links=driver.findElements(By.xpath("//table[@class='wikitable sortable jquery-tablesorter']/tbody/tr/td/a"));
	    for(int i=1;i<=5;i++) {
	    System.out.println(links.get(i).getText());
}
	}
}
