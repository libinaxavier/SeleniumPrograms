package ust.Seleniumpgms;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import ust.Configuration.BrowserConfig;

public class PiChart {
 WebDriver driver;
 
 @Test
 public void pichart() {
	 driver=BrowserConfig.getBrowser();
	 driver.navigate().to("https://clarle.github.io/yui3/yui/docs/charts/charts-pie.html");
     driver.manage().window().maximize();
     driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
     WebElement link=driver.findElement(By.xpath("//*[contains(@id,'yui_3_17_2_1_16902')][contains(@class,'yui3-shape yui3-svgShape yui3')][@fill='#66007f']"));
     Actions action=new Actions(driver);
     action.moveToElement(link).perform();
     WebElement l=driver.findElement(By.xpath("//div[contains(@id,'_tooltip')][contains(@class,'yui3-chart-tooltip')]//div"));
     System.out.println(l.getText());
 }
}